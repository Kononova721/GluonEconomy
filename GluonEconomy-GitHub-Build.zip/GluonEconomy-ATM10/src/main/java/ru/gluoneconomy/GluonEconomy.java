package ru.gluoneconomy;

import com.mojang.logging.LogUtils;
import net.neoforged.fml.common.Mod;
import org.slf4j.Logger;

@Mod(GluonEconomy.MOD_ID)
public final class GluonEconomy {
    public static final String MOD_ID = "gluon_economy";
    public static final Logger LOGGER = LogUtils.getLogger();

    public GluonEconomy() {
        // Client tooltip handler is registered through @EventBusSubscriber.
    }
}
