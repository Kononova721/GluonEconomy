package ru.gluoneconomy;

import com.google.gson.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.item.Item;
import net.minecraft.core.registries.BuiltInRegistries;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

final class PriceCalculator {
    private static final Gson GSON = new Gson();
    private static Map<String, Double> manualPrices = new HashMap<>();
    private static List<CraftRecipe> recipes = new ArrayList<>();
    private static boolean loaded = false;

    private PriceCalculator() {}

    static synchronized void ensureLoaded(ResourceManager manager) {
        if (loaded) return;
        loadManualPrices();
        loadCraftingRecipes(manager);
        loaded = true;
    }

    static synchronized OptionalDouble price(String itemId, ResourceManager manager) {
        ensureLoaded(manager);
        Double manual = manualPrices.get(itemId);
        if (manual != null) return OptionalDouble.of(manual);
        return calculate(itemId, new HashSet<>(), 0);
    }

    private static OptionalDouble calculate(String itemId, Set<String> visiting, int depth) {
        Double manual = manualPrices.get(itemId);
        if (manual != null) return OptionalDouble.of(manual);
        if (depth > 24 || !visiting.add(itemId)) return OptionalDouble.empty();

        double best = Double.POSITIVE_INFINITY;
        for (CraftRecipe recipe : recipes) {
            if (!recipe.outputId.equals(itemId) || recipe.outputCount <= 0) continue;
            double total = 0.0;
            boolean known = true;

            for (IngredientGroup group : recipe.ingredients) {
                double cheapest = Double.POSITIVE_INFINITY;
                for (String option : group.options) {
                    OptionalDouble optionPrice = calculate(option, visiting, depth + 1);
                    if (optionPrice.isPresent()) cheapest = Math.min(cheapest, optionPrice.getAsDouble());
                }
                if (!Double.isFinite(cheapest)) {
                    known = false;
                    break;
                }
                total += cheapest * group.count;
            }

            if (known) best = Math.min(best, total / recipe.outputCount);
        }

        visiting.remove(itemId);
        return Double.isFinite(best) ? OptionalDouble.of(best) : OptionalDouble.empty();
    }

    private static void loadManualPrices() {
        manualPrices.clear();
        var path = net.neoforged.fml.loading.FMLPaths.CONFIGDIR.get()
                .resolve("gluon_economy").resolve("prices.json");
        try {
            java.nio.file.Files.createDirectories(path.getParent());
            if (!java.nio.file.Files.exists(path)) {
                JsonObject defaults = new JsonObject();
                JsonObject prices = new JsonObject();
                prices.addProperty("minecraft:iron_ingot", 4);
                prices.addProperty("minecraft:copper_ingot", 3);
                prices.addProperty("minecraft:gold_ingot", 8);
                prices.addProperty("minecraft:coal", 1);
                prices.addProperty("minecraft:diamond", 32);
                defaults.add("prices", prices);
                java.nio.file.Files.writeString(path, GSON.toJson(defaults), StandardCharsets.UTF_8);
            }
            JsonObject root = JsonParser.parseString(
                    java.nio.file.Files.readString(path, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject prices = root.has("prices") ? root.getAsJsonObject("prices") : root;
            for (Map.Entry<String, JsonElement> entry : prices.entrySet()) {
                if (entry.getValue().isJsonPrimitive() && entry.getValue().getAsJsonPrimitive().isNumber()) {
                    double value = entry.getValue().getAsDouble();
                    if (value >= 0 && Double.isFinite(value)) manualPrices.put(entry.getKey(), value);
                }
            }
        } catch (Exception e) {
            GluonEconomy.LOGGER.error("Could not read Gluon Economy prices.json", e);
        }
    }

    private static void loadCraftingRecipes(ResourceManager manager) {
        recipes.clear();
        Map<ResourceLocation, Resource> resources = manager.listResources("recipes",
                id -> id.getPath().endsWith(".json"));
        for (Map.Entry<ResourceLocation, Resource> entry : resources.entrySet()) {
            try (var reader = new InputStreamReader(entry.getValue().open(), StandardCharsets.UTF_8)) {
                JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();
                String type = json.has("type") ? json.get("type").getAsString() : "";
                if (!type.equals("minecraft:crafting_shaped") &&
                    !type.equals("minecraft:crafting_shapeless")) continue;

                JsonObject result = json.has("result") && json.get("result").isJsonObject()
                        ? json.getAsJsonObject("result") : null;
                String outputId = null;
                int outputCount = 1;
                if (result != null) {
                    if (result.has("id")) outputId = result.get("id").getAsString();
                    else if (result.has("item")) outputId = result.get("item").getAsString();
                    if (result.has("count")) outputCount = result.get("count").getAsInt();
                } else if (json.has("result") && json.get("result").isJsonPrimitive()) {
                    outputId = json.get("result").getAsString();
                }
                if (outputId == null || outputCount <= 0 || !isRegisteredItem(outputId)) continue;

                List<IngredientGroup> ingredients = type.equals("minecraft:crafting_shapeless")
                        ? parseShapeless(json) : parseShaped(json);
                if (!ingredients.isEmpty()) recipes.add(new CraftRecipe(outputId, outputCount, ingredients));
            } catch (Exception ignored) {
                // Unsupported or malformed recipe formats are skipped safely.
            }
        }
    }

    private static boolean isRegisteredItem(String id) {
        try {
            return BuiltInRegistries.ITEM.containsKey(ResourceLocation.parse(id));
        } catch (Exception e) {
            return false;
        }
    }

    private static List<IngredientGroup> parseShapeless(JsonObject json) {
        List<IngredientGroup> result = new ArrayList<>();
        if (!json.has("ingredients") || !json.get("ingredients").isJsonArray()) return result;
        for (JsonElement element : json.getAsJsonArray("ingredients")) {
            List<String> options = parseItemOptions(element);
            if (!options.isEmpty()) result.add(new IngredientGroup(options, 1));
        }
        return result;
    }

    private static List<IngredientGroup> parseShaped(JsonObject json) {
        List<IngredientGroup> result = new ArrayList<>();
        if (!json.has("pattern") || !json.has("key")) return result;
        JsonObject key = json.getAsJsonObject("key");
        Map<String, Integer> counts = new HashMap<>();
        for (JsonElement row : json.getAsJsonArray("pattern")) {
            String line = row.getAsString();
            for (int i = 0; i < line.length(); i++) {
                String symbol = String.valueOf(line.charAt(i));
                if (symbol.equals(" ")) continue;
                counts.merge(symbol, 1, Integer::sum);
            }
        }
        for (Map.Entry<String, Integer> count : counts.entrySet()) {
            if (!key.has(count.getKey())) continue;
            List<String> options = parseItemOptions(key.get(count.getKey()));
            if (!options.isEmpty()) result.add(new IngredientGroup(options, count.getValue()));
        }
        return result;
    }

    private static List<String> parseItemOptions(JsonElement element) {
        List<String> result = new ArrayList<>();
        if (!element.isJsonObject()) return result;
        JsonObject object = element.getAsJsonObject();
        if (object.has("item")) {
            String id = object.get("item").getAsString();
            if (isRegisteredItem(id)) result.add(id);
        }
        if (object.has("items") && object.get("items").isJsonArray()) {
            for (JsonElement item : object.getAsJsonArray("items")) {
                String id = item.getAsString();
                if (isRegisteredItem(id)) result.add(id);
            }
        }
        // Tag-based ingredients and complex modded ingredients are intentionally skipped in this prototype.
        return result;
    }

    private record IngredientGroup(List<String> options, int count) {}
    private record CraftRecipe(String outputId, int outputCount, List<IngredientGroup> ingredients) {}
}
