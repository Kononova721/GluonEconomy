package ru.gluoneconomy;

import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

import java.util.Locale;
import java.util.OptionalDouble;

@EventBusSubscriber(modid = GluonEconomy.MOD_ID, value = Dist.CLIENT)
public final class ClientTooltips {
    private ClientTooltips() {}

    @SubscribeEvent
    public static void onItemTooltip(ItemTooltipEvent event) {
        if (event.getItemStack().isEmpty()) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.getResourceManager() == null) return;

        ResourceLocation key = BuiltInRegistries.ITEM.getKey(event.getItemStack().getItem());
        String id = key.toString();
        OptionalDouble price = PriceCalculator.price(id, minecraft.getResourceManager());

        if (price.isPresent()) {
            double value = price.getAsDouble();
            String formatted = Math.abs(value - Math.rint(value)) < 0.000001
                    ? String.format(Locale.ROOT, "%.0f", value)
                    : String.format(Locale.ROOT, "%.2f", value);
            event.getToolTip().add(Component.literal("Цена: " + formatted + " глюонов")
                    .withStyle(ChatFormatting.GOLD));
        } else {
            event.getToolTip().add(Component.literal("Цена: не определена")
                    .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        }
    }
}
