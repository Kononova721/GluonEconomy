@echo off
where gradle >nul 2>nul
if errorlevel 1 (echo Gradle is not installed. Install Gradle 8.8+ and Java 21. & pause & exit /b 1)
gradle build --no-daemon
pause
