#!/usr/bin/env sh
set -eu
command -v gradle >/dev/null 2>&1 || { echo "Gradle 8.8+ is not installed"; exit 1; }
gradle build --no-daemon
